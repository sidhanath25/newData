package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import dbutils.DBConnectivity;

public class LoginPage {

	WebDriver driver;
	@FindBy(xpath = "//input[@id='user_login']")
	WebElement username;

	@FindBy(xpath = "//input[@id='user_pass']")
	WebElement password;

	@FindBy(xpath = "//input[@id='wp-submit']")
	WebElement login;
	@FindBy(xpath="//li[contains(@id,'my-account')]/a//span")
	WebElement label;
	DBConnectivity dbData;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public void enterUserName(String uname) {
		username.sendKeys(uname);
	}

	public void clickLogin() {
		login.click();
	}

	public void enterPassword(String pwd) {
		password.sendKeys(pwd);
	}
	
	public Boolean validateUserName() throws Exception {
		dbData= new DBConnectivity();
		if(label.getText().equalsIgnoreCase(dbData.getuserName("username").get(0)))
		{
			return true;
		}
		return false;
	}

}
