package dbutils;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

public class DBConnectivity {
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;

	public ResultSet readDataBase() throws Exception {
		try {
			// This will load the MySQL driver, each DB has its own driver
			Class.forName("com.mysql.jdbc.Driver");
			// Setup the connection with the DB
			connect = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/MiniProject", "root", "");

			preparedStatement = ((java.sql.Connection) connect)
					.prepareStatement("select username,password  from `MiniProject`.`tbl2`");
			resultSet = preparedStatement.executeQuery();
			//writeResultSet(resultSet);
			return resultSet;

		} catch (Exception e) {
			throw e;
		} 
	}

	public void writeResultSet(ResultSet resultSet) throws SQLException {
		// ResultSet is initially before the first data set
		while (resultSet.next()) {
			// It is possible to get the columns via name
			// also possible to get the columns via the column number
			// which starts at 1
			// e.g. resultSet.getSTring(2);
			String user = resultSet.getString("username");
			String pwd = resultSet.getString("password");
			System.out.println("User: " + user);
			System.out.println("Password: " + pwd);

		}
	}
	
	
	public List<String> getuserName(String user) throws Exception {
		try {
			resultSet= readDataBase();
			List<String> uname= new ArrayList<String>();
			while (resultSet.next()) {
				// It is possible to get the columns via name
				// also possible to get the columns via the column number
				// which starts at 1
				// e.g. resultSet.getSTring(2);
				String u = resultSet.getString(user);
				uname.add(u);
			}
			return uname;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			close();
		}
		return null;
	}
	

	public List<String> getPassword(String pass) throws Exception {
		try {
			resultSet= readDataBase();
			List<String> pwd= new ArrayList<String>();
			while (resultSet.next()) {
				// It is possible to get the columns via name
				// also possible to get the columns via the column number
				// which starts at 1
				// e.g. resultSet.getSTring(2);
				String pasd = resultSet.getString(pass);
				pwd.add(pasd);
			}
			return pwd;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			close();
		}
		return null;
		

	}

	private void close() {

		try {
			if (resultSet != null) {
				resultSet.close();
			}

			if (statement != null) {
				statement.close();
			}

			if (connect != null) {
				((Statement) connect).close();
			}
		} catch (Exception e) {

		}

	}

}
