package dataReader;

import java.io.FileReader;
import java.io.IOException;

import com.opencsv.CSVReader;

public class ReadCsvData {

	public static String readData(String value) throws IOException {
		
		String CSV_PATH = System.getProperty("user.dir") + "//" + "src" + "//" + "main" + "//" + "resources" + "//"
				+ "data.csv";
		String[] csvCell;
		String valuex = null;
		String keyx = null;

		CSVReader csvReaderx = new CSVReader(new FileReader(CSV_PATH));

		// you can use while loop to read CSV data
		while ((csvCell = csvReaderx.readNext()) != null) {
			keyx = csvCell[0];
			valuex = csvCell[1];
			if (keyx.equalsIgnoreCase(value)) {
				break;
			}
		}

		csvReaderx.close();
		return valuex;

	}

}
