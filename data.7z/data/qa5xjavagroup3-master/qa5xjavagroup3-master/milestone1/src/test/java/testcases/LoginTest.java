package testcases;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;

import dataReader.ReadCsvData;
import dbutils.DBConnectivity;
import pageObjects.LoginPage;

public class LoginTest {
	private static WebDriver driver;
	WebElement element;
	LoginPage lpage;
	DBConnectivity dbData;

	@BeforeClass
	public static void openBrowser() throws IOException {
		String browser = ReadCsvData.readData("browser");
		if (browser.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver",
					System.getProperty("user.dir") + "//" + "Drivers" + "//" + "geckodriver.exe");
			driver = new FirefoxDriver();
		}

		else if (browser.equalsIgnoreCase("Chrome")) {
			System.out.println("In Chrome");
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "//" + "Drivers" + "//" + "chromedriver.exe");
			driver = new ChromeDriver();
		}

		else if (browser.equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.ie.driver",
					System.getProperty("user.dir") + "//" + "Drivers" + "//" + "IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(ReadCsvData.readData("URL"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	@Test
	public void valid_UserCred() throws SQLException, Exception {
		lpage = PageFactory.initElements(driver, LoginPage.class);
		dbData = new DBConnectivity();
		if (lpage == null) {
			lpage = new LoginPage(driver);
		}
		lpage.enterUserName(dbData.getuserName("username").get(0));
		lpage.enterPassword(dbData.getPassword("password").get(0));
		lpage.clickLogin();
		boolean flag = lpage.validateUserName();
		Assert.assertTrue(flag);

	}

	@AfterClass
	public static void closeBrowser() {
		driver.quit();
	}

}
